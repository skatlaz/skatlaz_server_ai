from pathlib import Path
import pandas as pd


def read_table(path: str, sheet_name=0) -> pd.DataFrame:
    p = Path(path)
    if p.suffix.lower() in ['.xlsx', '.xlsm', '.xls']:
        return pd.read_excel(p, sheet_name=sheet_name)
    if p.suffix.lower() == '.csv':
        return pd.read_csv(p)
    if p.suffix.lower() == '.ods':
        return pd.read_excel(p, engine='odf')
    raise ValueError('Formato de planilha não suportado')


def clean_table(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [str(c).strip().replace('\n',' ') for c in df.columns]
    for col in df.columns:
        if df[col].dtype == object:
            df[col] = df[col].astype(str).str.strip().replace({'nan':''})
            # tentar números com vírgula
            converted = pd.to_numeric(df[col].str.replace('.','', regex=False).str.replace(',','.', regex=False), errors='ignore')
            df[col] = converted
    return df.drop_duplicates()


def apply_prompt_formula(df: pd.DataFrame, prompt: str) -> pd.DataFrame:
    df = df.copy(); low = prompt.lower()
    nums = list(df.select_dtypes(include='number').columns)
    if 'lucro' in low and len(nums) >= 2:
        df['Lucro'] = df[nums[0]] - df[nums[1]]
    elif ('soma' in low or 'total' in low) and nums:
        df['Total_Calculado'] = df[nums].sum(axis=1)
    elif ('média' in low or 'media' in low) and nums:
        df['Media_Calculada'] = df[nums].mean(axis=1)
    elif 'percentual' in low and len(nums) >= 2:
        df['Percentual'] = (df[nums[0]] / df[nums[1]].replace(0, pd.NA)) * 100
    return df


def olap_summary(df: pd.DataFrame, index: str | None = None, value: str | None = None, agg='sum') -> pd.DataFrame:
    df = df.copy()
    if index is None:
        obj_cols = list(df.select_dtypes(exclude='number').columns)
        index = obj_cols[0] if obj_cols else df.columns[0]
    if value is None:
        nums = list(df.select_dtypes(include='number').columns)
        if not nums: raise ValueError('Nenhuma coluna numérica encontrada')
        value = nums[0]
    return pd.pivot_table(df, index=index, values=value, aggfunc=agg).reset_index()


def create_chart(df: pd.DataFrame, out_png: str, x: str | None = None, y: str | None = None, kind='bar', title='Skatlaz Chart') -> str:
    import matplotlib.pyplot as plt
    p = Path(out_png); p.parent.mkdir(parents=True, exist_ok=True)
    if x is None: x = df.columns[0]
    if y is None:
        nums = list(df.select_dtypes(include='number').columns)
        y = nums[0] if nums else df.columns[1]
    ax = df.plot(x=x, y=y, kind=kind, title=title, legend=True)
    fig = ax.get_figure(); fig.tight_layout(); fig.savefig(p, dpi=160); plt.close(fig)
    return str(p)


def save_excel(df: pd.DataFrame, out_xlsx: str, chart_png: str | None = None) -> str:
    from openpyxl import load_workbook
    from openpyxl.drawing.image import Image
    p = Path(out_xlsx); p.parent.mkdir(parents=True, exist_ok=True)
    df.to_excel(p, index=False, sheet_name='dados')
    if chart_png:
        wb = load_workbook(p); ws = wb.create_sheet('grafico'); ws.add_image(Image(chart_png), 'A1'); wb.save(p)
    return str(p)
