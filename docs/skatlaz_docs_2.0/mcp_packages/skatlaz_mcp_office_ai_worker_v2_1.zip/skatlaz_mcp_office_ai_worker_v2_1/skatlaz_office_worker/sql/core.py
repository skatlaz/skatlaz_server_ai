import sqlite3, pandas as pd
from pathlib import Path

def sqlite_query(db_path: str, query: str) -> pd.DataFrame:
    with sqlite3.connect(db_path) as conn:
        return pd.read_sql_query(query, conn)

def sqlite_to_excel(db_path: str, query: str, out_xlsx: str) -> str:
    df = sqlite_query(db_path, query)
    p=Path(out_xlsx); p.parent.mkdir(parents=True, exist_ok=True)
    df.to_excel(p, index=False)
    return str(p)
