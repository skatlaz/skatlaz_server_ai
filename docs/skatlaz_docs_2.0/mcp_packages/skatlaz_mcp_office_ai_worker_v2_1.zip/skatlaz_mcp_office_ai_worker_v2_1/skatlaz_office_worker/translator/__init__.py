from .core import translate_text_basic
