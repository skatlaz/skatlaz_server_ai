import re

_DICT = {
    ('pt','en'): {'relatório':'report','vendas':'sales','lucro':'profit','cliente':'customer','produto':'product','total':'total','resumo':'summary','arquivo':'file','documento':'document'},
    ('en','pt'): {'report':'relatório','sales':'vendas','profit':'lucro','customer':'cliente','product':'produto','summary':'resumo','file':'arquivo','document':'documento'}
}

def translate_text_basic(text: str, source='pt', target='en') -> str:
    d = _DICT.get((source,target), {})
    out = text
    for a,b in d.items():
        out = re.sub(rf'\b{re.escape(a)}\b', b, out, flags=re.IGNORECASE)
    return out + f'\n\n[Tradução básica offline {source}->{target}. Plugue LLM para tradução profissional.]'
