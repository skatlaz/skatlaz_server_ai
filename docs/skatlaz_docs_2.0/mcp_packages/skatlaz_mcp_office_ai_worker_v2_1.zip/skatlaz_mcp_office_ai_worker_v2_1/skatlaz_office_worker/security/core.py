from pathlib import Path
import hashlib, base64
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes

SALT = b'skatlaz-office-worker-v2'

def _key(password: str) -> bytes:
    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=SALT, iterations=390000)
    return base64.urlsafe_b64encode(kdf.derive(password.encode()))


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()


def encrypt_file(path: str, password: str, out_path: str | None = None) -> str:
    p=Path(path); out=Path(out_path or (str(p)+'.skenc'))
    out.write_bytes(Fernet(_key(password)).encrypt(p.read_bytes()))
    return str(out)


def decrypt_file(path: str, password: str, out_path: str | None = None) -> str:
    p=Path(path); out=Path(out_path or str(p).replace('.skenc','.dec'))
    out.write_bytes(Fernet(_key(password)).decrypt(p.read_bytes()))
    return str(out)
