from .core import read_url, extract_products_simple
