import re, requests
from bs4 import BeautifulSoup


def read_url(url: str, timeout=15) -> dict:
    r = requests.get(url, timeout=timeout, headers={'User-Agent':'SkatlazMCP/2.1'})
    r.raise_for_status()
    soup = BeautifulSoup(r.text, 'html.parser')
    title = soup.title.get_text(' ', strip=True) if soup.title else ''
    for tag in soup(['script','style','noscript']): tag.decompose()
    text = soup.get_text('\n', strip=True)
    links = [{'text': a.get_text(' ', strip=True), 'href': a.get('href')} for a in soup.find_all('a')[:100]]
    return {'url': url, 'title': title, 'text': text, 'links': links}


def extract_products_simple(text: str) -> list[dict]:
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    products=[]
    price_re = re.compile(r'(R\$\s?\d+[\.,]?\d*|\$\s?\d+[\.,]?\d*)')
    for line in lines:
        m = price_re.search(line)
        if m:
            products.append({'line': line[:220], 'price': m.group(1)})
    return products[:100]
