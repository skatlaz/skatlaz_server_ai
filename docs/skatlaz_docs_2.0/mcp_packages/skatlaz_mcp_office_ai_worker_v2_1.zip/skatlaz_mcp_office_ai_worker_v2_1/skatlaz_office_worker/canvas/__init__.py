from .core import render_html, create_report_html
