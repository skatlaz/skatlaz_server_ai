from pathlib import Path
from PIL import Image, ImageStat


def ocr_image(image_path: str, lang='por+eng') -> str:
    try:
        import pytesseract
        return pytesseract.image_to_string(Image.open(image_path), lang=lang)
    except Exception as e:
        return f'OCR indisponível ou Tesseract ausente: {e}'


def read_codes(image_path: str) -> list[dict]:
    try:
        from pyzbar.pyzbar import decode
        img = Image.open(image_path)
        return [{'type': c.type, 'data': c.data.decode('utf-8', errors='ignore')} for c in decode(img)]
    except Exception as e:
        return [{'error': f'Leitura de barcode/QR indisponível: {e}'}]


def create_qrcode(data: str, out_png: str) -> str:
    import qrcode
    p = Path(out_png); p.parent.mkdir(parents=True, exist_ok=True)
    img = qrcode.make(data); img.save(p); return str(p)


def create_barcode(data: str, out_png_prefix: str, barcode_type='code128') -> str:
    import barcode
    from barcode.writer import ImageWriter
    p = Path(out_png_prefix); p.parent.mkdir(parents=True, exist_ok=True)
    cls = barcode.get_barcode_class(barcode_type)
    return cls(data, writer=ImageWriter()).save(str(p))


def describe_image_basic(image_path: str) -> dict:
    img = Image.open(image_path).convert('RGB')
    stat = ImageStat.Stat(img)
    w,h = img.size
    brightness = sum(stat.mean)/3
    return {'width': w, 'height': h, 'mode': img.mode, 'average_rgb': stat.mean, 'brightness': brightness, 'description': 'imagem clara' if brightness > 150 else 'imagem escura ou contrastada'}
