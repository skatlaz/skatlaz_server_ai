from pathlib import Path
import re
from html import escape


def read_document(path: str) -> str:
    p = Path(path)
    ext = p.suffix.lower()
    if ext in ['.txt', '.md', '.csv', '.log']:
        return p.read_text(encoding='utf-8', errors='ignore')
    if ext in ['.html', '.htm']:
        from bs4 import BeautifulSoup
        return BeautifulSoup(p.read_text(encoding='utf-8', errors='ignore'), 'html.parser').get_text('\n')
    if ext == '.docx':
        from docx import Document
        doc = Document(str(p))
        parts = [para.text for para in doc.paragraphs]
        for table in doc.tables:
            for row in table.rows:
                parts.append(' | '.join(cell.text for cell in row.cells))
        return '\n'.join(parts)
    if ext == '.pdf':
        try:
            import pdfplumber
            text=[]
            with pdfplumber.open(str(p)) as pdf:
                for page in pdf.pages:
                    text.append(page.extract_text() or '')
            return '\n'.join(text)
        except Exception:
            from pypdf import PdfReader
            return '\n'.join(page.extract_text() or '' for page in PdfReader(str(p)).pages)
    if ext == '.odt':
        from odf.opendocument import load
        from odf import teletype
        from odf.text import P
        doc = load(str(p))
        return '\n'.join(teletype.extractText(p) for p in doc.getElementsByType(P))
    raise ValueError(f'Formato não suportado: {ext}')


def summarize_text(text: str, max_sentences: int = 6) -> str:
    cleaned = re.sub(r'\s+', ' ', text).strip()
    sentences = re.split(r'(?<=[.!?])\s+', cleaned)
    if len(sentences) <= max_sentences:
        return cleaned
    words = re.findall(r'\w+', cleaned.lower())
    stop = set('a o e de da do das dos um uma uns umas para por com sem em no na nos nas que se os as is the and of to in for on'.split())
    freq = {}
    for w in words:
        if w not in stop and len(w) > 2:
            freq[w] = freq.get(w, 0) + 1
    scored = []
    for i, s in enumerate(sentences):
        score = sum(freq.get(w.lower(),0) for w in re.findall(r'\w+', s))
        scored.append((score, i, s))
    chosen = sorted(sorted(scored, reverse=True)[:max_sentences], key=lambda x: x[1])
    return '\n'.join(s for _,_,s in chosen)


def correct_text_basic(text: str) -> str:
    replacements = {
        'voce':'você','nao':'não','entao':'então','tambem':'também','ja':'já','esta':'está',
        'aqruivo':'arquivo','faer':'fazer','mcp':'MCP','chatgpt':'ChatGPT'
    }
    out = text
    for a,b in replacements.items():
        out = re.sub(rf'\b{re.escape(a)}\b', b, out, flags=re.IGNORECASE)
    out = re.sub(r' +', ' ', out)
    return out


def write_txt(path: str, text: str) -> str:
    p = Path(path); p.parent.mkdir(parents=True, exist_ok=True); p.write_text(text, encoding='utf-8'); return str(p)


def write_html(path: str, title: str, body_text: str) -> str:
    html = f'<!doctype html><html><head><meta charset="utf-8"><title>{escape(title)}</title><style>body{{font-family:Arial;margin:40px;line-height:1.6}} .box{{max-width:960px;margin:auto}}</style></head><body><div class="box"><h1>{escape(title)}</h1><pre>{escape(body_text)}</pre></div></body></html>'
    return write_txt(path, html)


def convert_markdown_to_html(md_path: str, out_html: str) -> str:
    import markdown
    text = Path(md_path).read_text(encoding='utf-8', errors='ignore')
    html_body = markdown.markdown(text, extensions=['tables'])
    return write_txt(out_html, f'<!doctype html><html><meta charset="utf-8"><body>{html_body}</body></html>')
