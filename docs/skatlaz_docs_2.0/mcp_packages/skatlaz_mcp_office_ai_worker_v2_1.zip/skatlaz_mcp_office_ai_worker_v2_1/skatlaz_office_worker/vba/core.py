def generate_vba_macro(task: str) -> str:
    low = task.lower()
    if 'pdf' in low:
        return '''Sub ExportarPDF()\n    ActiveSheet.ExportAsFixedFormat Type:=xlTypePDF, Filename:=ThisWorkbook.Path & "\\relatorio.pdf"\nEnd Sub'''
    if 'tabela' in low or 'pivot' in low:
        return '''Sub AtualizarTabelas()\n    Dim pt As PivotTable\n    Dim ws As Worksheet\n    For Each ws In ThisWorkbook.Worksheets\n        For Each pt In ws.PivotTables\n            pt.RefreshTable\n        Next pt\n    Next ws\nEnd Sub'''
    return '''Sub SkatlazMacro()\n    MsgBox "Macro gerada pelo Skatlaz MCP Office AI Worker"\nEnd Sub'''
